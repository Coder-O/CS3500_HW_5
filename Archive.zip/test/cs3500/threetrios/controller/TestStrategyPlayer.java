package cs3500.threetrios.controller;

/**
 * A testing class for a strategy player.
 */
public class TestStrategyPlayer {
  
}
