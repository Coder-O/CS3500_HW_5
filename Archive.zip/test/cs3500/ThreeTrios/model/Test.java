package cs3500.ThreeTrios.model;

public @interface Test {

    Class<IllegalStateException> expected();

}
