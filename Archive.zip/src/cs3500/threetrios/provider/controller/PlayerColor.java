package cs3500.threetrios.provider.controller;

/**
 * Two colors representing the two plauers in a game of ThreeTrios.
 */
public enum PlayerColor {

  //R is Red, B is Blue.
  R, B;
}
