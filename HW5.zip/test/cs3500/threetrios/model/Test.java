package cs3500.threetrios.model;

public @interface Test {

    Class<IllegalStateException> expected();

}
